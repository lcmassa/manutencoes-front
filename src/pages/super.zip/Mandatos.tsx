import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react'
import { useAuth } from '../contexts/AuthContext'
import api from '../lib/api'
import { TokenInfo } from '../components/TokenInfo'
import { 
  carregarAssembleias, 
  salvarAssembleia, 
  atualizarDataRealizada,
  mesclarDadosMandatoComAssembleia,
  salvarAssembleiasEmBatch,
  type AssembleiaData 
} from '../utils/assembleias-db'
import { Edit2, Check, X } from 'lucide-react'

type Mandato = {
  id: string
  condominio: string
  nomeFantasia: string
  nomeResponsavel: string
  cargo: string
  dataEntrada: string
  dataSaida: string | null
  email: string
  telefone: string
  celular: string
  status: 'ativo' | 'encerrado' | 'futuro'
  observacoes?: string
}

export function Mandatos() {
  const { token, companyId } = useAuth()
  const [data, setData] = useState<Mandato[]>([])
  const [loading, setLoading] = useState(true)
  const [erro, setErro] = useState<string | null>(null)
  const [searchTerm, setSearchTerm] = useState<string>('')
  const [ordenacao, setOrdenacao] = useState<'vencimento' | 'nome'>('vencimento')
  const loadingRef = useRef(false)
  const tokenExpiredRef = useRef(false)
  const [assembleiasDB, setAssembleiasDB] = useState<Map<string, AssembleiaData>>(new Map())
  const [editandoId, setEditandoId] = useState<string | null>(null)
  const [dataRealizadaEditando, setDataRealizadaEditando] = useState<string>('')

  // Função auxiliar para parse de datas (memoizada para evitar recriações)
  const parseDate = useCallback((dateString: string): Date | null => {
    if (!dateString || dateString === '-') return null
    try {
      // Se já está no formato dd/mm/yyyy, parsear diretamente
      if (/^\d{2}\/\d{2}\/\d{4}$/.test(dateString.trim())) {
        const dateParts = dateString.trim().split('/')
        const dia = parseInt(dateParts[0], 10)
        const mes = parseInt(dateParts[1], 10) - 1 // Mês é 0-indexed em Date
        const ano = parseInt(dateParts[2], 10)
        
        // Validar se os valores são válidos
        if (isNaN(dia) || isNaN(mes) || isNaN(ano)) return null
        if (dia < 1 || dia > 31 || mes < 0 || mes > 11 || ano < 1900 || ano > 2100) return null
        
        return new Date(ano, mes, dia)
      }
      
      // Formato esperado: "01/01/2018 00:00:00" ou "01/01/2018" (DD/MM/YYYY)
      const parts = dateString.trim().split(' ')
      const datePart = parts[0]
      const dateParts = datePart.split('/')
      
      if (dateParts.length === 3) {
        // DD/MM/YYYY (formato brasileiro)
        const dia = parseInt(dateParts[0], 10)
        const mes = parseInt(dateParts[1], 10) - 1 // Mês é 0-indexed em Date
        const ano = parseInt(dateParts[2], 10)
        
        // Validar se os valores são válidos
        if (isNaN(dia) || isNaN(mes) || isNaN(ano)) return null
        if (dia < 1 || dia > 31 || mes < 0 || mes > 11 || ano < 1900 || ano > 2100) return null
        
        return new Date(ano, mes, dia)
      }
      
      // Tentar parse direto (formato ISO ou outros)
      const date = new Date(dateString)
      if (isNaN(date.getTime())) return null
      return date
    } catch {
      return null
    }
  }, [])

  const carregarMandatos = useCallback(async () => {
    // Evita múltiplas requisições simultâneas
    if (loadingRef.current) {
      console.log('[Mandatos] Requisição já em andamento, ignorando...')
      return
    }
    
    // Se já detectamos token expirado, não tenta novamente automaticamente
    if (tokenExpiredRef.current) {
      console.log('[Mandatos] Token expirado detectado anteriormente, ignorando requisição automática...')
      return
    }
    
    console.log('[Mandatos] ========== INICIANDO CARREGAMENTO DE MANDATOS ==========')
    console.log('[Mandatos] Timestamp:', new Date().toISOString())
    console.log('[Mandatos] Token disponível:', !!token)
    console.log('[Mandatos] Token (primeiros 20 chars):', token ? token.substring(0, 20) + '...' : 'N/A')
    console.log('[Mandatos] Company ID:', companyId)
    
    if (!token) {
      console.error('[Mandatos] ❌ ERRO: Token não disponível!')
      setErro('Token de autenticação não disponível. Aguarde a autenticação ou recarregue a página.')
      setLoading(false)
      loadingRef.current = false
      return
    }
    
    loadingRef.current = true
    setLoading(true)
    setErro(null)
    
    // Timeout de segurança: se demorar mais de 5 minutos, cancelar
    const timeoutId = setTimeout(() => {
      if (loadingRef.current) {
        console.error('[Mandatos] ⚠️ Timeout: Carregamento demorou mais de 5 minutos, cancelando...')
        setErro('Timeout: O carregamento demorou muito. Tente recarregar a página ou verifique sua conexão.')
        setLoading(false)
        loadingRef.current = false
      }
    }, 5 * 60 * 1000) // 5 minutos
    
    try {
      const currentCompanyId = companyId || localStorage.getItem('x-company-id') || 'abimoveis-003'
      console.log('[Mandatos] Company ID final:', currentCompanyId)
      
      // Função auxiliar para fazer requisição de uma página específica
      const fazerRequisicaoPagina = async (comStatus: string, idCondominio?: string, pagina: number = 1): Promise<{ list: any[], totalPaginas?: number, totalItens?: number }> => {
        const params = new URLSearchParams({
          itensPorPagina: '50', // API recomenda no máximo 50 (conforme Postman)
          pagina: String(pagina),
        })
        
        if (idCondominio) {
          params.append('idCondominio', idCondominio)
        }
        
        // Só adiciona comStatus se não for vazio (string vazia significa buscar todos sem filtro)
        if (comStatus && comStatus.trim() !== '') {
          params.append('comStatus', comStatus.trim())
        }
        
        const url = `/api/condominios/superlogica/sindicos?${params.toString()}`
        const statusLabel = comStatus && comStatus.trim() !== '' ? comStatus : 'todos (sem filtro)'
        console.log(`[Mandatos] Buscando ${statusLabel} página ${pagina} na URL:`, url)
        
        let responseData: any
        
        try {
          console.log(`[Mandatos] 🔍 Fazendo requisição para: ${url}`)
          // Usar a nova API que injeta token automaticamente
          const response = await api.get<any>(url)
          
          console.log(`[Mandatos] ✅ Resposta recebida - Status: ${response.status}`)
          
          // A nova API retorna { data, status, statusText }
          responseData = response.data
          
          // Log detalhado da resposta da API
          console.log(`[Mandatos] 📦 Resposta da API (página ${pagina}, ${comStatus || 'sem filtro'}):`, {
            tipo: Array.isArray(responseData) ? 'array' : typeof responseData,
            keys: typeof responseData === 'object' && responseData !== null ? Object.keys(responseData) : [],
            preview: Array.isArray(responseData) 
              ? `Array com ${responseData.length} itens` 
              : typeof responseData === 'object' && responseData !== null
              ? JSON.stringify(responseData).substring(0, 200)
              : String(responseData).substring(0, 200)
          })
          
          if (Array.isArray(responseData) && responseData.length > 0) {
            console.log(`[Mandatos] ✅ Array com ${responseData.length} itens recebido`)
            console.log(`[Mandatos] Primeiro item:`, responseData[0])
          } else if (responseData && typeof responseData === 'object') {
            console.log(`[Mandatos] 📋 Objeto recebido, chaves:`, Object.keys(responseData))
          } else {
            console.warn(`[Mandatos] ⚠️ Resposta vazia ou inesperada`)
          }
        } catch (err: any) {
          // Tratar erros da nova API
          const status = err?.response?.status || 500
          const errorData = err?.response?.data || err?.message || 'Erro desconhecido'
          
          console.error(`[Mandatos] ❌ ERRO ao buscar ${comStatus || 'sem filtro'} página ${pagina}:`, {
            status,
            error: errorData,
            url,
            erroCompleto: err
          })
          
          if (status === 401) {
            tokenExpiredRef.current = true
            console.error(`[Mandatos] ❌ Token expirado ou inválido!`)
            console.error(`[Mandatos] ❌ Para renovar, execute: ./iap auth`)
            // Parar todas as requisições pendentes
            throw new Error(`HTTP ${status}: Token de autenticação expirado ou inválido. Execute: ./iap auth`)
          } else if (status === 422) {
            // Erro 422: retornar lista vazia
            console.warn(`[Mandatos] ⚠️ Retornando lista vazia devido ao erro 422`)
            return { list: [], totalPaginas: 0, totalItens: 0 }
          }
          
          // Log detalhado do erro
          console.error(`[Mandatos] Erro completo:`, {
            message: err?.message,
            response: err?.response,
            stack: err?.stack
          })
          
          throw new Error(`HTTP ${status}: ${typeof errorData === 'string' ? errorData : JSON.stringify(errorData)}`)
        }
        
        // Continuar processamento apenas se chegou aqui (sem erro)
        if (!responseData) {
          return { list: [], totalPaginas: 0, totalItens: 0 }
        }
        
        // Log completo da estrutura da resposta para debug
        if (typeof responseData === 'object' && responseData !== null && !Array.isArray(responseData)) {
          console.log(`[Mandatos] Estrutura completa da resposta (página ${pagina}):`, {
            status: responseData.status,
            session: responseData.session,
            msg: responseData.msg,
            dataLength: Array.isArray(responseData.data) ? responseData.data.length : 'não é array',
            totalPaginas: responseData.totalPaginas,
            totalItens: responseData.totalItens,
            total: responseData.total,
            executiontime: responseData.executiontime,
            todasAsChaves: Object.keys(responseData)
          })
        }
        
        // Extrair lista de dados
        let list: any[] = []
        let totalPaginas: number | undefined
        let totalItens: number | undefined
        
        if (Array.isArray(responseData)) {
          list = responseData
        } else if (responseData?.data && Array.isArray(responseData.data)) {
          list = responseData.data
          // Tentar extrair informações de paginação
          if (responseData.totalPaginas !== undefined) totalPaginas = responseData.totalPaginas
          if (responseData.totalItens !== undefined) totalItens = responseData.totalItens
          if (responseData.total !== undefined) totalItens = responseData.total
        } else if (responseData?.sindicos && Array.isArray(responseData.sindicos)) {
          list = responseData.sindicos
        } else if (responseData?.result && Array.isArray(responseData.result)) {
          list = responseData.result
        } else if (typeof responseData === 'object' && responseData !== null) {
          const keys = Object.keys(responseData)
          for (const key of keys) {
            if (Array.isArray(responseData[key])) {
              list = responseData[key]
              console.log(`[Mandatos] Lista encontrada na chave "${key}" com ${list.length} itens`)
              break
            }
          }
          // Tentar extrair informações de paginação
          if (responseData.totalPaginas !== undefined) totalPaginas = responseData.totalPaginas
          if (responseData.totalItens !== undefined) totalItens = responseData.totalItens
          if (responseData.total !== undefined) totalItens = responseData.total
        }
        
        // Log detalhado dos condomínios únicos nesta página
        if (list.length > 0) {
          const condominiosUnicos = new Set(list.map((item: any) => 
            item.st_nome_cond || item.ST_NOME_COND || item.condominio || 'Sem nome'
          ))
          console.log(`[Mandatos] Página ${pagina}: ${list.length} itens, ${condominiosUnicos.size} condomínios únicos:`, Array.from(condominiosUnicos))
        } else {
          console.log(`[Mandatos] Página ${pagina}: Nenhum item retornado`)
        }
        
        return { list, totalPaginas, totalItens }
      }
      
      // Função para buscar todas as páginas de um status
      const fazerRequisicaoCompleta = async (comStatus: string, idCondominio?: string): Promise<any[]> => {
        // Verificar se token expirou antes de começar
        if (tokenExpiredRef.current) {
          console.warn(`[Mandatos] ⚠️ Token expirado detectado, parando busca de ${comStatus}`)
          return []
        }
        
        let todasPaginas: any[] = []
        let paginaAtual = 1
        let temMaisPaginas = true
        let totalPaginasConhecido: number | undefined
        let itensPorPagina = 50 // Valor usado na requisição (API recomenda máximo 50)
        
        while (temMaisPaginas && !tokenExpiredRef.current) {
          // Verificar novamente antes de cada requisição
          if (tokenExpiredRef.current) {
            console.warn(`[Mandatos] ⚠️ Token expirado durante busca, parando...`)
            break
          }
          
          const resultado = await fazerRequisicaoPagina(comStatus, idCondominio, paginaAtual)
          todasPaginas = todasPaginas.concat(resultado.list)
          
          const statusLabel = comStatus && comStatus.trim() !== '' ? comStatus : 'todos'
          console.log(`[Mandatos] ${statusLabel} página ${paginaAtual}: ${resultado.list.length} itens`)
          
          // Se a API retornou informação de total de páginas, usar isso
          if (resultado.totalPaginas !== undefined) {
            totalPaginasConhecido = resultado.totalPaginas
            temMaisPaginas = paginaAtual < totalPaginasConhecido
            console.log(`[Mandatos] ${statusLabel} total de páginas conhecido: ${totalPaginasConhecido}`)
          } else if (resultado.totalItens !== undefined) {
            // Calcular total de páginas baseado no total de itens
            const calculado = Math.ceil(resultado.totalItens / itensPorPagina)
            if (totalPaginasConhecido === undefined || calculado > totalPaginasConhecido) {
              totalPaginasConhecido = calculado
            }
            temMaisPaginas = totalPaginasConhecido !== undefined && paginaAtual < totalPaginasConhecido
            console.log(`[Mandatos] ${statusLabel} total de itens: ${resultado.totalItens}, páginas calculadas: ${totalPaginasConhecido}`)
          } else {
            // Caso contrário, parar se retornou menos que o máximo de itens
            // Se retornou exatamente itensPorPagina, provavelmente há mais páginas
            if (resultado.list.length === itensPorPagina) {
              temMaisPaginas = true
              console.log(`[Mandatos] ${statusLabel} página ${paginaAtual} retornou ${resultado.list.length} itens (máximo), continuando...`)
            } else {
              // Retornou menos que o máximo - esta é a última página
              console.log(`[Mandatos] ${statusLabel} página ${paginaAtual} retornou ${resultado.list.length} itens (menos que máximo), última página`)
              temMaisPaginas = false
            }
          }
          
          // Limite de segurança: máximo 200 páginas
          if (paginaAtual >= 200) {
            console.warn(`[Mandatos] ⚠️ Limite de 200 páginas atingido para ${statusLabel}`)
            temMaisPaginas = false
            break
          }
          
          // Se não retornou itens, parar
          if (resultado.list.length === 0) {
            console.log(`[Mandatos] ${statusLabel} página ${paginaAtual} retornou 0 itens, parando paginação`)
            temMaisPaginas = false
            break
          }
          
          // Incrementar página ANTES de continuar
          paginaAtual++
          
          // Proteção adicional: se já processou muitas páginas sem encontrar dados novos, parar
          if (paginaAtual > 10 && todasPaginas.length === 0) {
            console.warn(`[Mandatos] ⚠️ Processou ${paginaAtual} páginas sem encontrar dados, parando`)
            temMaisPaginas = false
            break
          }
        }
        
        const statusLabel = comStatus && comStatus.trim() !== '' ? comStatus : 'todos'
        const condominiosUnicos = new Set(todasPaginas.map((item: any) => 
          item.st_nome_cond || item.ST_NOME_COND || item.condominio || 'Sem nome'
        ))
        console.log(`[Mandatos] ${statusLabel} total: ${todasPaginas.length} itens de ${paginaAtual - 1} página(s)`)
        console.log(`[Mandatos] ${statusLabel} condomínios únicos encontrados: ${condominiosUnicos.size}`)
        if (condominiosUnicos.size > 0) {
          console.log(`[Mandatos] ${statusLabel} lista de condomínios:`, Array.from(condominiosUnicos).slice(0, 10))
        }
        return todasPaginas
      }
      
      // ESTRATÉGIA: Buscar todos os condomínios primeiro, depois buscar síndicos para cada um
      // Isso garante que pegamos todos os 68 condomínios
      console.log('[Mandatos] ========== BUSCANDO TODOS OS CONDOMÍNIOS PRIMEIRO ==========')
      console.log('[Mandatos] Company ID:', currentCompanyId)
      
      // Passo 1: Buscar todos os condomínios
      let todosCondominios: any[] = []
      let paginaCondominios = 1
      let temMaisCondominios = true
      
      try {
        while (temMaisCondominios) {
          try {
            const urlCondominios = `/api/condominios/superlogica/condominios/get?id=-1&somenteCondominiosAtivos=1&ignorarCondominioModelo=1&itensPorPagina=100&pagina=${paginaCondominios}`
            console.log(`[Mandatos] Buscando condomínios ATIVOS página ${paginaCondominios}...`)
            console.log(`[Mandatos] URL: ${urlCondominios}`)
            const responseCondominios = await api.get<any>(urlCondominios)
            
            const dataCondominios = responseCondominios.data
            const listCondominios = Array.isArray(dataCondominios) 
              ? dataCondominios 
              : dataCondominios?.data || dataCondominios?.condominios || []
            
            if (listCondominios.length === 0) {
              console.log(`[Mandatos] Nenhum condomínio encontrado na página ${paginaCondominios}, parando...`)
              temMaisCondominios = false
              break
            }
            
            todosCondominios = todosCondominios.concat(listCondominios)
            console.log(`[Mandatos] Condomínios página ${paginaCondominios}: ${listCondominios.length} encontrados (total: ${todosCondominios.length})`)
            
            // Se retornou menos que 100, é a última página
            if (listCondominios.length < 100) {
              temMaisCondominios = false
            } else {
              paginaCondominios++
              // Limite de segurança
              if (paginaCondominios > 50) {
                console.warn('[Mandatos] ⚠️ Limite de 50 páginas de condomínios atingido')
                temMaisCondominios = false
              }
            }
          } catch (err: any) {
            console.error(`[Mandatos] Erro ao buscar condomínios página ${paginaCondominios}:`, err)
            // Se for erro 401, parar imediatamente
            if (err?.response?.status === 401) {
              tokenExpiredRef.current = true
              throw err
            }
            temMaisCondominios = false
          }
        }
        
        console.log(`[Mandatos] ✅ Total de condomínios encontrados: ${todosCondominios.length}`)
        
        // Fallback: se não encontrou nenhum, tentar uma consulta sem filtros (alguns ambientes não aceitam os parâmetros de filtro)
        if (todosCondominios.length === 0) {
          try {
            const urlCondominiosFallback = `/api/condominios/superlogica/condominios/get?id=-1&itensPorPagina=100&pagina=1`
            console.warn('[Mandatos] ⚠️ Nenhum condomínio encontrado com filtros. Tentando fallback sem filtros...')
            console.warn('[Mandatos] URL (fallback):', urlCondominiosFallback)
            const responseFallback = await api.get<any>(urlCondominiosFallback)
            const dataFallback = responseFallback.data
            const listFallback = Array.isArray(dataFallback)
              ? dataFallback
              : dataFallback?.data || dataFallback?.condominios || []
            if (Array.isArray(listFallback) && listFallback.length > 0) {
              todosCondominios = listFallback
              console.warn(`[Mandatos] ✅ Fallback retornou ${listFallback.length} condomínios`)
            } else {
              console.warn('[Mandatos] ⚠️ Fallback também não retornou condomínios')
            }
          } catch (fallbackErr) {
            console.warn('[Mandatos] ⚠️ Erro no fallback de condomínios:', fallbackErr)
          }
        }
        
        // Validação: não pode haver mais condomínios do que o esperado (68)
        if (todosCondominios.length > 68) {
          console.warn(`[Mandatos] ⚠️ ATENÇÃO: Encontrados ${todosCondominios.length} condomínios, mas a AB tem apenas 68 cadastrados!`)
        }
        
        // Se não encontrou nenhum condomínio, mostrar erro e parar
        if (todosCondominios.length === 0) {
          console.warn('[Mandatos] ⚠️ Nenhum condomínio encontrado!')
          setErro('Nenhum condomínio encontrado. Verifique se a empresa selecionada possui condomínios cadastrados.')
          setLoading(false)
          loadingRef.current = false
          return
        }
      } catch (err: any) {
        console.error('[Mandatos] Erro ao buscar condomínios:', err)
        if (err?.response?.status === 401) {
          tokenExpiredRef.current = true
          setErro('Token de autenticação expirado. Para renovar, execute no terminal: ./iap auth\n\nDepois, recarregue a página.')
        } else {
          setErro(`Erro ao buscar condomínios: ${err?.message || 'Erro desconhecido'}`)
        }
        setLoading(false)
        loadingRef.current = false
        return
      }
      
      // Passo 2: Buscar síndicos para cada condomínio (com limite e delay para evitar loop)
      console.log('[Mandatos] ========== BUSCANDO SÍNDICOS PARA CADA CONDOMÍNIO ==========')
      let todasListas: any[] = []
      
      // Limitar a 100 condomínios para evitar loop infinito
      const condominiosParaProcessar = todosCondominios.slice(0, 100)
      console.log(`[Mandatos] Processando ${condominiosParaProcessar.length} de ${todosCondominios.length} condomínios (limite de 100)`)
      
      // Função auxiliar para delay entre requisições
      const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms))
      
      try {
        // Buscar síndicos para cada condomínio (com processamento em lotes para melhorar performance)
        // Processar em lotes de 10 condomínios em paralelo para acelerar ainda mais
        const batchSize = 10 // Processar 10 condomínios por vez (aumentado de 5 para 10)
        for (let batchStart = 0; batchStart < condominiosParaProcessar.length; batchStart += batchSize) {
          const batch = condominiosParaProcessar.slice(batchStart, batchStart + batchSize)
          
          // Processar lote em paralelo (mas com limite)
          await Promise.all(batch.map(async (condominio, batchIndex) => {
            const i = batchStart + batchIndex
            const idCondominio = condominio.id_condominio_cond || condominio.ID_CONDOMINIO_COND || condominio.id
            if (!idCondominio) {
              console.warn(`[Mandatos] ⚠️ Condomínio sem ID:`, condominio)
              return
            }
            
            const nomeCondominio = condominio.st_fantasia_cond || condominio.ST_FANTASIA_COND || condominio.st_nome_cond || condominio.nome || 'Sem nome'
            
            // Verificar se já foi interrompido
            if (tokenExpiredRef.current) {
              console.warn('[Mandatos] ⚠️ Token expirado durante busca, parando...')
              return
            }
            
            // Buscar 'atuais' e 'passado' para este condomínio
            for (const status of ['atuais', 'passado']) {
              try {
                // Delay mínimo: apenas 20ms entre requisições do mesmo condomínio (reduzido de 50ms)
                if (status === 'passado') {
                  await delay(20)
                }
                
                const resultados = await fazerRequisicaoCompleta(status, String(idCondominio))
                todasListas = todasListas.concat(resultados)
                if (resultados.length > 0) {
                  console.log(`[Mandatos] [${i + 1}/${condominiosParaProcessar.length}] ${nomeCondominio} (${status}): ${resultados.length} síndicos`)
                }
              } catch (err: any) {
                // Se for erro 401, parar tudo
                if (err?.response?.status === 401) {
                  tokenExpiredRef.current = true
                  throw err
                }
                console.warn(`[Mandatos] ⚠️ Erro ao buscar ${status} do condomínio ${nomeCondominio}:`, err)
                // Continuar para o próximo condomínio mesmo se houver erro
              }
            }
          }))
          
          // Delay mínimo entre lotes (reduzido para 20ms para acelerar)
          if (batchStart + batchSize < condominiosParaProcessar.length) {
            await delay(20)
          }
        }
        
        console.log(`[Mandatos] ✅ Total de síndicos encontrados (todos os condomínios): ${todasListas.length}`)
        
        // Validação: não pode haver mais síndicos do que condomínios
        if (todasListas.length > todosCondominios.length) {
          console.warn(`[Mandatos] ⚠️ ATENÇÃO: Encontrados ${todasListas.length} síndicos, mas apenas ${todosCondominios.length} condomínios!`)
          console.warn(`[Mandatos] ⚠️ Isso pode indicar duplicatas ou cargos inválidos sendo incluídos.`)
        }
      } catch (err: any) {
        console.error('[Mandatos] Erro ao buscar síndicos:', err)
        if (err?.response?.status === 401) {
          tokenExpiredRef.current = true
          setErro('Token de autenticação expirado. Para renovar, execute no terminal: ./iap auth\n\nDepois, recarregue a página.')
        } else {
          setErro(`Erro ao buscar síndicos: ${err?.message || 'Erro desconhecido'}`)
        }
        setLoading(false)
        loadingRef.current = false
        return
      }
      
      console.log('[Mandatos] ========== RESUMO FINAL ==========')
      console.log('[Mandatos] Lista total combinada:', todasListas.length, 'itens')
      if (todasListas.length > 0) {
        console.log('[Mandatos] Primeiros itens da lista:', todasListas.slice(0, 3))
        console.log('[Mandatos] Últimos itens da lista:', todasListas.slice(-3))
        // Log detalhado: mostrar quantos itens únicos temos por condomínio
        const contagemPorCondominio = new Map<string, number>()
        todasListas.forEach((item: any) => {
          const cond = item.st_nome_cond || item.ST_NOME_COND || item.condominio || 'Sem nome'
          contagemPorCondominio.set(cond, (contagemPorCondominio.get(cond) || 0) + 1)
        })
        console.log('[Mandatos] Contagem de itens por condomínio:', Array.from(contagemPorCondominio.entries()).slice(0, 10))
        console.log('[Mandatos] Total de condomínios únicos na lista bruta:', contagemPorCondominio.size)
      } else {
        console.warn('[Mandatos] ⚠️ NENHUM ITEM ENCONTRADO! Verifique:')
        console.warn('[Mandatos]   1. Se a busca de condomínios funcionou')
        console.warn('[Mandatos]   2. Se a busca de responsáveis legais retornou dados')
        console.warn('[Mandatos]   3. Se há erros 422 nas requisições')
      }
      
      // Mapear os dados da API para o formato Mandato
      const hoje = new Date()
      hoje.setHours(0, 0, 0, 0)
      
      // Log detalhado dos dados recebidos
      console.log('Itens recebidos da API:', todasListas.length)
      if (todasListas.length > 0) {
        todasListas.slice(0, 5).forEach((m: any, idx: number) => {
          const cargo = m.st_cargo_sin || m.ST_CARGO_SIN || m.cargo || ''
          console.log(`Item ${idx + 1}: cargo="${cargo}", condomínio="${m.st_nome_cond || m.ST_NOME_COND || m.condominio}"`)
        })
        
        // Mostrar todos os cargos únicos encontrados
        const cargosUnicos = new Set(todasListas.map((m: any) => m.st_cargo_sin || m.ST_CARGO_SIN || m.cargo || 'Sem cargo'))
        console.log('Cargos únicos encontrados:', Array.from(cargosUnicos))
      }
      
      // Filtrar apenas cargos que são variações de "SINDICO" ou "SINDICA"
      // Função para remover acentos
      const removerAcentos = (str: string): string => {
        return str.normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      }
      
      const isCargoSindico = (cargo: string): boolean => {
        if (!cargo || typeof cargo !== 'string') {
          return false
        }
        // Remover espaços extras, converter para maiúsculas e remover acentos
        const cargoNormalizado = removerAcentos(cargo.trim().toUpperCase().replace(/\s+/g, ' '))
        
        // Aceitar APENAS as variações exatas: SINDICO ou SINDICA (sem sufixos)
        // Não aceitar: SINDICO PRO TEMPORE, SINDICA SUBSTITUTA, etc.
        const eSindicoExato = cargoNormalizado === 'SINDICO'
        const eSindicaExata = cargoNormalizado === 'SINDICA'
        
        return eSindicoExato || eSindicaExata
      }
      
      // Log de debug: mostrar alguns cargos antes do filtro
      const cargosAntesFiltro = todasListas.slice(0, 20).map((m: any) => {
        const cargo = m.st_cargo_sin || m.ST_CARGO_SIN || m.cargo || ''
        const passa = isCargoSindico(cargo)
        const cargoNormalizado = removerAcentos(cargo.trim().toUpperCase().replace(/\s+/g, ' '))
        return { cargo, cargoNormalizado, passa }
      })
      console.log('[Mandatos] Exemplos de cargos antes do filtro (primeiros 20):', cargosAntesFiltro)
      
      // Mostrar cargos que foram REJEITADOS (para debug)
      const cargosRejeitados = todasListas
        .filter((m: any) => {
          const cargo = m.st_cargo_sin || m.ST_CARGO_SIN || m.cargo || ''
          return !isCargoSindico(cargo)
        })
        .slice(0, 10)
        .map((m: any) => {
          const cargo = m.st_cargo_sin || m.ST_CARGO_SIN || m.cargo || ''
          const cargoNormalizado = removerAcentos(cargo.trim().toUpperCase().replace(/\s+/g, ' '))
          return { cargo, cargoNormalizado }
        })
      if (cargosRejeitados.length > 0) {
        console.log('[Mandatos] Exemplos de cargos REJEITADOS (primeiros 10):', cargosRejeitados)
      }
      
      const todasListasFiltradas = todasListas.filter((m: any) => {
        const cargo = m.st_cargo_sin || m.ST_CARGO_SIN || m.cargo || ''
        const passa = isCargoSindico(cargo)
        return passa
      })
      
      console.log(`[Mandatos] Filtrando cargos de SINDICO/SINDICA: ${todasListas.length} -> ${todasListasFiltradas.length} itens`)
      
      // Mostrar cargos únicos após filtro
      const cargosUnicosFiltrados = new Set(todasListasFiltradas.map((m: any) => m.st_cargo_sin || m.ST_CARGO_SIN || m.cargo || 'Sem cargo'))
      console.log('[Mandatos] Cargos únicos após filtro (SINDICO/SINDICA):', Array.from(cargosUnicosFiltrados))
      
      // Log detalhado: mostrar quantos síndicos temos por condomínio após filtro
      const contagemPorCondominioFiltrado = new Map<string, number>()
      todasListasFiltradas.forEach((item: any) => {
        const cond = item.st_nome_cond || item.ST_NOME_COND || item.condominio || 'Sem nome'
        contagemPorCondominioFiltrado.set(cond, (contagemPorCondominioFiltrado.get(cond) || 0) + 1)
      })
      console.log('[Mandatos] Contagem de síndicos por condomínio (após filtro de cargo):', Array.from(contagemPorCondominioFiltrado.entries()).slice(0, 20))
      console.log('[Mandatos] Total de condomínios únicos após filtro de cargo:', contagemPorCondominioFiltrado.size)
      console.log('[Mandatos] Total de síndicos únicos (sem deduplicação):', todasListasFiltradas.length)
      
      // Verificar se há cargos que não deveriam passar
      const cargosInvalidos = todasListasFiltradas.filter((m: any) => {
        const cargo = m.st_cargo_sin || m.ST_CARGO_SIN || m.cargo || ''
        return !isCargoSindico(cargo)
      })
      if (cargosInvalidos.length > 0) {
        console.error('[Mandatos] ⚠️ ERRO: Encontrados cargos inválidos após filtro:', cargosInvalidos.slice(0, 5).map((m: any) => m.st_cargo_sin || m.ST_CARGO_SIN || m.cargo))
      }
      
      // Análise detalhada dos condomínios (após filtro)
      const condominiosUnicosSet = new Set(todasListasFiltradas.map((m: any) => m.st_nome_cond || m.ST_NOME_COND || m.condominio || 'Sem nome'))
      const condominiosComContagem = Array.from(condominiosUnicosSet).map(cond => ({
        nome: cond,
        quantidade: todasListasFiltradas.filter((m: any) => (m.st_nome_cond || m.ST_NOME_COND || m.condominio || 'Sem nome') === cond).length
      }))
      
      console.log('Condomínios únicos encontrados (após filtro):', condominiosUnicosSet.size)
      console.log('Distribuição por condomínio:', condominiosComContagem)
      
      if (condominiosUnicosSet.size === 1) {
        console.warn('⚠️ ATENÇÃO: Apenas 1 condomínio encontrado! Isso pode indicar:')
        console.warn('  1. A API está retornando apenas dados de um condomínio')
        console.warn('  2. Há um filtro sendo aplicado na API que limita os resultados')
        console.warn('  3. A paginação não está funcionando corretamente')
        console.warn('  4. O parâmetro idCondominio pode estar sendo usado implicitamente')
      }
      
      const mapped: Mandato[] = todasListasFiltradas
        .map((m: any) => {
          // Determinar status baseado nas datas
          let status: 'ativo' | 'encerrado' | 'futuro' = 'ativo'
          
          const dataEntrada = m.dt_entrada_sin ? parseDate(m.dt_entrada_sin) : null
          const dataSaida = m.dt_saida_sin ? parseDate(m.dt_saida_sin) : null
          
          if (dataSaida && dataSaida < hoje) {
            status = 'encerrado'
          } else if (dataEntrada && dataEntrada > hoje) {
            status = 'futuro'
          } else if (dataEntrada && dataEntrada <= hoje && (!dataSaida || dataSaida >= hoje)) {
            status = 'ativo'
          }

          // Formatar datas para dd/mm/yyyy ao mapear
          const dataEntradaRaw = m.dt_entrada_sin || m.DT_ENTRADA_SIN || m.data_entrada || ''
          const dataSaidaRaw = m.dt_saida_sin || m.DT_SAIDA_SIN || m.data_saida || null
          
          // Formatar datas para dd/mm/yyyy
          const formatarDataParaDDMMYYYY = (dateString: string | null): string => {
            if (!dateString || dateString.trim() === '') return '-'
            
            // Se já está no formato dd/mm/yyyy, retornar como está
            if (/^\d{2}\/\d{2}\/\d{4}$/.test(dateString.trim())) {
              return dateString.trim()
            }
            
            // Tentar parsear e formatar
            const date = parseDate(dateString)
            if (!date) {
              // Se não conseguiu parsear, tentar formatar diretamente se for ISO
              try {
                const dateISO = new Date(dateString)
                if (!isNaN(dateISO.getTime())) {
                  const dia = String(dateISO.getDate()).padStart(2, '0')
                  const mes = String(dateISO.getMonth() + 1).padStart(2, '0')
                  const ano = dateISO.getFullYear()
                  return `${dia}/${mes}/${ano}`
                }
              } catch {
                // Ignorar erro
              }
              return dateString // Retornar original se não conseguir formatar
            }
            
            // Formatar como dd/mm/yyyy
            const dia = String(date.getDate()).padStart(2, '0')
            const mes = String(date.getMonth() + 1).padStart(2, '0')
            const ano = date.getFullYear()
            return `${dia}/${mes}/${ano}`
          }

          return {
            id: String(m.id_sindico_sin || m.ID_SINDICO_SIN || m.id || Math.random()),
            condominio: m.st_nome_cond || m.ST_NOME_COND || m.condominio || 'Não informado',
            nomeFantasia: m.st_fantasia_cond || m.ST_FANTASIA_COND || m.nome_fantasia || m.condominio || 'Não informado',
            nomeResponsavel: m.st_nome_sin || m.ST_NOME_SIN || m.nome || 'Não informado',
            cargo: m.st_cargo_sin || m.ST_CARGO_SIN || m.cargo || 'Não informado',
            dataEntrada: formatarDataParaDDMMYYYY(dataEntradaRaw),
            dataSaida: formatarDataParaDDMMYYYY(dataSaidaRaw),
            email: m.st_email_sin || m.ST_EMAIL_SIN || m.email || '',
            telefone: m.st_telefone_sin || m.ST_TELEFONE_SIN || m.telefone || '',
            celular: m.st_celular_sin || m.ST_CELULAR_SIN || m.celular || '',
            status,
            observacoes: m.st_observacao_sin || m.ST_OBSERVACAO_SIN || m.observacoes || undefined,
          }
        })
        // Ordenar por data de saída em ordem crescente (nulls por último)
        // IMPORTANTE: As datas já estão formatadas como dd/mm/yyyy, então precisamos parsear novamente para ordenar
        .sort((a, b) => {
          const dataSaidaA = a.dataSaida && a.dataSaida !== '-' ? parseDate(a.dataSaida) : null
          const dataSaidaB = b.dataSaida && b.dataSaida !== '-' ? parseDate(b.dataSaida) : null
          
          // Se ambos têm data de saída, ordena crescente (mais antiga primeiro)
          if (dataSaidaA && dataSaidaB) {
            return dataSaidaA.getTime() - dataSaidaB.getTime()
          }
          // Se apenas A tem data, A vem primeiro (antes dos nulls)
          if (dataSaidaA && !dataSaidaB) {
            return -1
          }
          // Se apenas B tem data, B vem primeiro (antes dos nulls)
          if (!dataSaidaA && dataSaidaB) {
            return 1
          }
          // Se nenhum tem data, ordena por data de entrada crescente como fallback
          const dataEntradaA = a.dataEntrada && a.dataEntrada !== '-' ? parseDate(a.dataEntrada) : null
          const dataEntradaB = b.dataEntrada && b.dataEntrada !== '-' ? parseDate(b.dataEntrada) : null
          if (dataEntradaA && dataEntradaB) {
            return dataEntradaA.getTime() - dataEntradaB.getTime()
          }
          return 0
        })
      
      // Verificação final: garantir que todos os cargos mapeados são SINDICO/SINDICA
      const mappedFiltrado = mapped.filter(item => {
        const passa = isCargoSindico(item.cargo)
        if (!passa) {
          console.warn(`[Mandatos] ⚠️ Cargo removido no filtro final: "${item.cargo}"`)
        }
        return passa
      })
      
      console.log(`[Mandatos] Dados mapeados e ordenados: ${mapped.length} -> ${mappedFiltrado.length} itens (apenas cargos SINDICO/SINDICA, ordenados por data de saída)`)
      
      // Remover duplicatas: manter apenas um síndico por condomínio (o mais recente/ativo)
      // Como há 68 condomínios, não pode haver mais de 68 síndicos
      const condominiosUnicosMap = new Map<string, Mandato>()
      
      // Função para normalizar nome do condomínio
      const normalizarNomeCondominio = (nome: string): string => {
        return removerAcentos(nome.trim().toUpperCase().replace(/\s+/g, ' '))
      }
      
      mappedFiltrado.forEach((mandato) => {
        const nomeCondominioNormalizado = normalizarNomeCondominio(mandato.condominio)
        const mandatoExistente = condominiosUnicosMap.get(nomeCondominioNormalizado)
        
        if (!mandatoExistente) {
          // Primeira ocorrência deste condomínio
          condominiosUnicosMap.set(nomeCondominioNormalizado, mandato)
        } else {
          // Já existe um síndico para este condomínio - decidir qual manter
          // Prioridade: 1. Status ativo, 2. Data de entrada mais recente, 3. Data de fim mais distante
          const dataEntradaAtual = mandato.dataEntrada && mandato.dataEntrada !== '-' ? parseDate(mandato.dataEntrada) : null
          const dataEntradaExistente = mandatoExistente.dataEntrada && mandatoExistente.dataEntrada !== '-' ? parseDate(mandatoExistente.dataEntrada) : null
          const dataFimAtual = mandato.dataSaida && mandato.dataSaida !== '-' ? parseDate(mandato.dataSaida) : null
          const dataFimExistente = mandatoExistente.dataSaida && mandatoExistente.dataSaida !== '-' ? parseDate(mandatoExistente.dataSaida) : null
          
          let deveSubstituir = false
          
          // Priorizar mandatos ativos
          if (mandato.status === 'ativo' && mandatoExistente.status !== 'ativo') {
            deveSubstituir = true
          } else if (mandato.status !== 'ativo' && mandatoExistente.status === 'ativo') {
            deveSubstituir = false
          } else if (dataEntradaAtual && dataEntradaExistente) {
            // Se ambos têm mesmo status, comparar por data de entrada (mais recente = melhor)
            if (dataEntradaAtual.getTime() > dataEntradaExistente.getTime()) {
              deveSubstituir = true
            } else if (dataEntradaAtual.getTime() === dataEntradaExistente.getTime()) {
              // Se datas de entrada são iguais, comparar por data de fim (mais distante = melhor)
              if (dataFimAtual && dataFimExistente) {
                if (dataFimAtual.getTime() > dataFimExistente.getTime()) {
                  deveSubstituir = true
                }
              } else if (dataFimAtual && !dataFimExistente) {
                // Atual tem data de fim, existente não - preferir atual
                deveSubstituir = true
              }
            }
          } else if (dataEntradaAtual && !dataEntradaExistente) {
            // Mandato atual tem data, existente não tem - substituir
            deveSubstituir = true
          }
          
          if (deveSubstituir) {
            condominiosUnicosMap.set(nomeCondominioNormalizado, mandato)
            console.log(`[Mandatos] Substituindo síndico do condomínio "${mandato.condominio}"`)
          }
        }
      })
      
      let mandatosUnicos = Array.from(condominiosUnicosMap.values())
      console.log(`[Mandatos] Removendo duplicatas: ${mappedFiltrado.length} -> ${mandatosUnicos.length} mandatos únicos (um por condomínio)`)
      
      // Reordenar após remover duplicatas (por data de saída crescente)
      mandatosUnicos = mandatosUnicos.sort((a, b) => {
        const dataSaidaA = a.dataSaida && a.dataSaida !== '-' ? parseDate(a.dataSaida) : null
        const dataSaidaB = b.dataSaida && b.dataSaida !== '-' ? parseDate(b.dataSaida) : null
        
        // Se ambos têm data de saída, ordena crescente (mais antiga primeiro)
        if (dataSaidaA && dataSaidaB) {
          return dataSaidaA.getTime() - dataSaidaB.getTime()
        }
        // Se apenas A tem data, A vem primeiro (antes dos nulls)
        if (dataSaidaA && !dataSaidaB) {
          return -1
        }
        // Se apenas B tem data, B vem primeiro (antes dos nulls)
        if (!dataSaidaA && dataSaidaB) {
          return 1
        }
        // Se nenhum tem data, ordena por data de entrada crescente como fallback
        const dataEntradaA = a.dataEntrada && a.dataEntrada !== '-' ? parseDate(a.dataEntrada) : null
        const dataEntradaB = b.dataEntrada && b.dataEntrada !== '-' ? parseDate(b.dataEntrada) : null
        if (dataEntradaA && dataEntradaB) {
          return dataEntradaA.getTime() - dataEntradaB.getTime()
        }
        return 0
      })
      
      if (mandatosUnicos.length > 68) {
        console.warn(`[Mandatos] ⚠️ ATENÇÃO: Ainda há ${mandatosUnicos.length} síndicos únicos, mas deveria haver no máximo 68!`)
        console.warn(`[Mandatos] ⚠️ Isso pode indicar que há condomínios com nomes diferentes mas que são o mesmo condomínio.`)
      }
      
      // Log dos cargos únicos no resultado final
      const cargosFinais = new Set(mappedFiltrado.map(m => m.cargo))
      console.log('[Mandatos] Cargos únicos no resultado final:', Array.from(cargosFinais))
      
      // REMOVIDO: Lógica de deduplicação por condomínio
      // O usuário quer ver TODOS os síndicos, não apenas um por condomínio
      // Se houver múltiplos síndicos para o mesmo condomínio, mostrar todos
      
      console.log(`[Mandatos] Total de mandatos encontrados: ${mappedFiltrado.length}`)
      
      // Log de condomínios
      const nomesCondominios = mappedFiltrado.map(m => m.condominio)
      const condominiosUnicos = new Set(nomesCondominios)
      console.log(`[Mandatos] ✅ Total de mandatos: ${mappedFiltrado.length}`)
      console.log(`[Mandatos] ✅ Condomínios únicos: ${condominiosUnicos.size}`)
      if (nomesCondominios.length > 0 && nomesCondominios.length <= 20) {
        console.log('[Mandatos] Lista de condomínios:', nomesCondominios)
      } else if (nomesCondominios.length > 20) {
        console.log('[Mandatos] Primeiros 10 condomínios:', nomesCondominios.slice(0, 10))
        console.log('[Mandatos] Últimos 10 condomínios:', nomesCondominios.slice(-10))
      }
      
      console.log('[Mandatos] ========== FINALIZANDO CARREGAMENTO ==========')
      console.log('[Mandatos] Total de mandatos encontrados (antes de remover duplicatas):', mappedFiltrado.length)
      console.log('[Mandatos] Total de mandatos únicos (após remover duplicatas):', mandatosUnicos.length)
      
      if (mandatosUnicos.length === 0) {
        console.warn('[Mandatos] ⚠️ NENHUM MANDATO ENCONTRADO!')
        console.warn('[Mandatos] Verificando possíveis causas:')
        console.warn('[Mandatos] - Lista total antes do filtro:', todasListas.length)
        console.warn('[Mandatos] - Lista após filtro de cargo:', todasListasFiltradas.length)
        console.warn('[Mandatos] - Lista após mapeamento:', mapped.length)
        console.warn('[Mandatos] - Lista após filtro final:', mappedFiltrado.length)
        console.warn('[Mandatos] - Lista após remover duplicatas:', mandatosUnicos.length)
        
        // Se não há dados, definir array vazio mas não mostrar erro
        setData([])
        setErro(null) // Limpar erro se não há dados (pode ser que simplesmente não existam mandatos)
      } else {
        console.log('[Mandatos] ✅ Definindo', mandatosUnicos.length, 'mandatos únicos no estado')
        
        // Validação final: não pode haver mais síndicos do que condomínios (68)
        if (mandatosUnicos.length > 68) {
          console.warn(`[Mandatos] ⚠️ ATENÇÃO: Encontrados ${mandatosUnicos.length} síndicos únicos, mas a AB tem apenas 68 condomínios!`)
          console.warn(`[Mandatos] ⚠️ Verificando se há condomínios com nomes diferentes mas que são o mesmo...`)
          
          // Mostrar cargos únicos para debug
          const cargosUnicos = new Set(mandatosUnicos.map(m => m.cargo))
          console.warn(`[Mandatos] Cargos únicos encontrados:`, Array.from(cargosUnicos))
          
          // Mostrar condomínios únicos
          const condominiosUnicos = new Set(mandatosUnicos.map(m => m.condominio))
          console.warn(`[Mandatos] Condomínios únicos: ${condominiosUnicos.size}`)
        }
        
        setData(mandatosUnicos)
      }
  } catch (e: any) {
    let errorMessage = e?.message || String(e)
    
    // Melhorar mensagens de erro comuns
    if (errorMessage.includes('Failed to fetch') || errorMessage.includes('NetworkError')) {
      errorMessage = 'Erro de conexão: Não foi possível conectar ao servidor. Verifique sua conexão ou se o servidor está rodando.'
    } else if (errorMessage.includes('Timeout')) {
      errorMessage = 'Timeout: A requisição demorou muito para responder.\n\n' +
        'Possíveis causas:\n' +
        '• A API está lenta ou sobrecarregada\n' +
        '• Problemas de conexão com o servidor\n' +
        '• A empresa selecionada pode não ter dados ou ter muitos registros\n\n' +
        'Tente:\n' +
        '• Selecionar outra empresa no seletor do topo\n' +
        '• Verificar sua conexão com a internet\n' +
        '• Tentar novamente em alguns instantes'
    } else if (errorMessage.includes('401') || errorMessage.includes('expirado') || errorMessage.includes('expired')) {
      tokenExpiredRef.current = true
      errorMessage = 'Token de autenticação expirado. Para renovar, execute no terminal: ./iap auth\n\nDepois, recarregue a página.'
    } else if (errorMessage.includes('403') || errorMessage.includes('Permissão') || errorMessage.includes('permissão')) {
      errorMessage = 'Acesso negado: Você não tem permissão para acessar este recurso.\n\n' + 
        (errorMessage.includes('abimoveis') ? 'Tente selecionar outra empresa no seletor no topo da página.' : '')
    } else if (errorMessage.includes('404')) {
      errorMessage = 'Recurso não encontrado (404): O endpoint não existe ou foi movido.'
    }
    
    setErro(errorMessage)
    console.error('Erro ao carregar mandatos:', e)
    } finally {
      clearTimeout(timeoutId)
      setLoading(false)
      loadingRef.current = false
    }
  }, [token, companyId, parseDate]) // parseDate é estável, não causa loop

  // Ref para rastrear se já carregou os dados para este token/companyId
  const lastLoadRef = useRef<{ token: string | null; companyId: string | null; timestamp: number }>({ 
    token: null, 
    companyId: null,
    timestamp: 0
  })
  
  useEffect(() => {
    let isMounted = true
    let timeoutId: NodeJS.Timeout | null = null
    
    // Só carregar se houver token
    if (!token) {
      console.log('[Mandatos] Aguardando token...')
      setLoading(false)
      setErro('Token não disponível. Aguarde a autenticação.')
      return
    }
    
    // Verificar se já carregou para este token/companyId (com debounce de 500ms)
    const currentKey = `${token}-${companyId}`
    const lastKey = `${lastLoadRef.current.token}-${lastLoadRef.current.companyId}`
    const timeSinceLastLoad = Date.now() - lastLoadRef.current.timestamp
    
    if (currentKey === lastKey && timeSinceLastLoad < 500) {
      console.log('[Mandatos] Já carregou para este token/companyId recentemente, ignorando...')
      return
    }
    
    // Evitar múltiplas chamadas
    if (loadingRef.current) {
      console.log('[Mandatos] Já está carregando, ignorando...')
      return
    }
    
    if (!tokenExpiredRef.current) {
      // Debounce: aguardar 300ms antes de carregar para evitar múltiplas chamadas rápidas
      timeoutId = setTimeout(() => {
        if (!isMounted) return
        
        // Verificar novamente se já está carregando
        if (loadingRef.current) {
          console.log('[Mandatos] Já está carregando (após debounce), ignorando...')
          return
        }
        
        // Marcar que está carregando para este token/companyId ANTES de chamar
        lastLoadRef.current = { token, companyId, timestamp: Date.now() }
        carregarMandatos()
      }, 300)
    }
    
    return () => {
      isMounted = false
      if (timeoutId) {
        clearTimeout(timeoutId)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, companyId]) // Não incluir carregarMandatos para evitar loops

  // Filtrar e ordenar dados
  // Log para debug (apenas quando há mudanças significativas)
  const dataLengthRef = useRef(0)
  if (data.length !== dataLengthRef.current) {
    dataLengthRef.current = data.length
    console.log('[Mandatos] Dados no estado:', data.length, 'itens')
    if (data.length > 0) {
      const statusCount = data.reduce((acc, item) => {
        acc[item.status] = (acc[item.status] || 0) + 1
        return acc
      }, {} as Record<string, number>)
      console.log('[Mandatos] Distribuição por status:', statusCount)
    }
  }

  const filteredData = useMemo(() => {
    return data
      .filter(item => {
        // Mostrar TODOS os mandatos (ativos, encerrados e futuros)
        // Removido filtro de status para mostrar todos
        return true
      })
    .filter(item => {
      const matchesSearch = !searchTerm || 
        item.condominio.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.nomeResponsavel.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.cargo.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.email.toLowerCase().includes(searchTerm.toLowerCase())
      
      return matchesSearch
    })
    // Ordenar conforme seleção do usuário
    .sort((a, b) => {
      if (ordenacao === 'nome') {
        // Ordenar por nome do condomínio (A-Z)
        return a.condominio.localeCompare(b.condominio, 'pt-BR', { sensitivity: 'base' })
      } else {
        // Ordenar por data de fim (Saída) em ordem crescente
        // Vencidos aparecem primeiro (datas passadas), depois próximos a vencer
        const dataFimA = a.dataSaida ? parseDate(a.dataSaida) : null
        const dataFimB = b.dataSaida ? parseDate(b.dataSaida) : null
        
        // Se ambos têm data de fim, ordena crescente (vencimentos mais próximos primeiro)
        // Datas passadas (vencidas) terão valores menores e aparecerão primeiro
        if (dataFimA && dataFimB) {
          return dataFimA.getTime() - dataFimB.getTime()
        }
        // Se apenas A tem data, A vem primeiro (antes dos sem data)
        if (dataFimA && !dataFimB) {
          return -1
        }
        // Se apenas B tem data, B vem primeiro (antes dos sem data)
        if (!dataFimA && dataFimB) {
          return 1
        }
        // Se nenhum tem data, ordena por data de início como fallback
        const dataInicioA = a.dataEntrada ? parseDate(a.dataEntrada) : null
        const dataInicioB = b.dataEntrada ? parseDate(b.dataEntrada) : null
        if (dataInicioA && dataInicioB) {
          return dataInicioA.getTime() - dataInicioB.getTime()
        }
        return 0
      }
    })
  }, [data, searchTerm, ordenacao, parseDate])

  const getStatusBadge = (status: string) => {
    const styles = {
      ativo: "bg-green-100 text-green-800",
      encerrado: "bg-gray-100 text-gray-800",
      futuro: "bg-blue-100 text-blue-800"
    }
    return (
      <span className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium ${styles[status as keyof typeof styles] || 'bg-gray-100 text-gray-800'}`}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    )
  }

  const formatDate = (dateString: string | null) => {
    if (!dateString) return '-'
    try {
      const date = parseDate(dateString)
      if (!date) return dateString
      
      // Formatar sempre como dd/mm/yyyy
      const dia = String(date.getDate()).padStart(2, '0')
      const mes = String(date.getMonth() + 1).padStart(2, '0')
      const ano = date.getFullYear()
      return `${dia}/${mes}/${ano}`
    } catch {
      return dateString
    }
  }

  // Calcular dias até vencimento do mandato
  const calcularDiasAteVencimento = (dataFim: string | null): number | null => {
    if (!dataFim) return null
    const hoje = new Date()
    hoje.setHours(0, 0, 0, 0)
    const fim = parseDate(dataFim)
    if (!fim) return null
    fim.setHours(0, 0, 0, 0)
    const diffTime = fim.getTime() - hoje.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  // Determinar estilo da linha baseado no status do mandato
  const getRowStyle = (item: Mandato): string => {
    const diasAteVencimento = calcularDiasAteVencimento(item.dataSaida)
    
    if (diasAteVencimento === null) {
      // Sem data de fim - estilo normal
      return 'border-b border-gray-200 hover:bg-gray-50'
    }
    
    if (diasAteVencimento < 0) {
      // Mandato vencido - fundo vermelho
      return 'border-b border-gray-200 bg-red-100 hover:bg-red-200'
    } else if (diasAteVencimento <= 60) {
      // Até 60 dias para vencer - fundo amarelo
      return 'border-b border-gray-200 bg-yellow-100 hover:bg-yellow-200'
    }
    
    // Mais de 60 dias - estilo normal
    return 'border-b border-gray-200 hover:bg-gray-50'
  }
  
  // Calcular previsão de assembleia (30 dias antes do vencimento)
  const calcularPrevisaoAssembleia = (dataFim: string | null): string => {
    if (!dataFim) return '-'
    const fim = parseDate(dataFim)
    if (!fim) return '-'
    
    // Assembleia 30 dias antes do vencimento
    const previsao = new Date(fim)
    previsao.setDate(previsao.getDate() - 30)
    
    // Formatar diretamente como dd/mm/yyyy
    const dia = String(previsao.getDate()).padStart(2, '0')
    const mes = String(previsao.getMonth() + 1).padStart(2, '0')
    const ano = previsao.getFullYear()
    return `${dia}/${mes}/${ano}`
  }

  // Obter texto da previsão de eleição
  const getPrevisaoEleicao = (item: Mandato): string => {
    const diasAteVencimento = calcularDiasAteVencimento(item.dataSaida)
    
    if (diasAteVencimento === null) {
      return '-'
    }
    
    if (diasAteVencimento < 0) {
      return `Vencido há ${Math.abs(diasAteVencimento)} dia(s)`
    }
    
    if (diasAteVencimento <= 30) {
      return `⚠️ ${diasAteVencimento} dia(s) - ALERTA`
    }
    
    if (diasAteVencimento <= 60) {
      return `${diasAteVencimento} dia(s)`
    }
    
    return `${diasAteVencimento} dia(s)`
  }

  // Carregar dados do banco ao montar componente
  useEffect(() => {
    const assembleias = carregarAssembleias()
    const map = new Map<string, AssembleiaData>()
    assembleias.forEach(a => map.set(a.id, a))
    setAssembleiasDB(map)
  }, [])

  // Mesclar dados do mandato com dados do banco (otimizado - usa Map em memória)
  const dadosComAssembleias = useMemo(() => {
    const novasAssembleias: AssembleiaData[] = []
    const novoMap = new Map(assembleiasDB)
    
    const resultado = filteredData.map(item => {
      const previsaoAssembleia = calcularPrevisaoAssembleia(item.dataSaida)
      const assembleia = mesclarDadosMandatoComAssembleia(
        item.condominio,
        item.nomeResponsavel,
        item.dataEntrada || '-',
        item.dataSaida || '-',
        previsaoAssembleia,
        assembleiasDB // Passar Map em memória ao invés de ler do localStorage
      )
      
      // Adicionar ao Map se não existir
      if (!novoMap.has(assembleia.id)) {
        novoMap.set(assembleia.id, assembleia)
        novasAssembleias.push(assembleia)
      }
      
      return {
        ...item,
        assembleia
      }
    })
    
    // Atualizar estado e salvar em batch de forma assíncrona (não bloqueia renderização)
    if (novasAssembleias.length > 0) {
      // Atualizar estado primeiro (rápido)
      setAssembleiasDB(novoMap)
      
      // Salvar no localStorage em batch depois (não bloqueia - uma única escrita)
      Promise.resolve().then(() => {
        salvarAssembleiasEmBatch(novasAssembleias)
      })
    }
    
    return resultado
  }, [filteredData, assembleiasDB])

  const iniciarEdicao = (id: string, dataRealizada: string) => {
    setEditandoId(id)
    setDataRealizadaEditando(dataRealizada || '')
  }

  const salvarEdicao = (id: string) => {
    if (dataRealizadaEditando && !/^\d{2}\/\d{2}\/\d{4}$/.test(dataRealizadaEditando.trim())) {
      alert('Formato de data inválido. Use dd/mm/yyyy (ex: 15/11/2025)')
      return
    }

    atualizarDataRealizada(id, dataRealizadaEditando.trim())
    
    const assembleias = carregarAssembleias()
    const map = new Map<string, AssembleiaData>()
    assembleias.forEach(a => map.set(a.id, a))
    setAssembleiasDB(map)
    
    setEditandoId(null)
    setDataRealizadaEditando('')
  }

  const cancelarEdicao = () => {
    setEditandoId(null)
    setDataRealizadaEditando('')
  }

      return (
        <div>
          {/* Box com informações do Token JWT */}
          <TokenInfo token={token} />

          {/* Mensagem de erro */}
          {erro && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-800 text-sm font-semibold mb-2">Erro ao carregar mandatos:</p>
          <p className="text-red-700 text-sm mb-3 whitespace-pre-line">{erro}</p>
          {erro.includes('expirado') || erro.includes('expired') ? (
            <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded">
              <p className="text-yellow-800 text-xs font-semibold mb-1">Como renovar o token:</p>
              <code className="block text-xs bg-gray-100 p-2 rounded mb-2">./iap auth</code>
              <p className="text-yellow-700 text-xs">Execute este comando no terminal e depois recarregue a página.</p>
            </div>
          ) : (
            <p className="text-red-600 text-xs mb-2">Verifique o console do navegador (F12) para mais detalhes.</p>
          )}
          <button
            onClick={() => {
              tokenExpiredRef.current = false
              carregarMandatos()
            }}
            className="mt-2 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 text-sm"
          >
            Tentar novamente
          </button>
        </div>
      )}

      {/* Título - Estilo da imagem */}
      <h1 className="text-xl font-semibold text-gray-800 mb-4">
        Controle de Vencimento de Mandatos
      </h1>

        {/* Barra de Pesquisa - Estilo da imagem */}
        <div className="mb-4">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <svg className="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Pesquisar..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Loading */}
        {loading && (
          <div className="mb-4 p-4 text-center">
            <p className="text-gray-600">Carregando mandatos...</p>
          </div>
        )}

        {/* Tabela - Estilo da imagem */}
        {!loading && !erro && dadosComAssembleias.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            Nenhum mandato encontrado.
          </div>
        )}
        
        {!loading && dadosComAssembleias.length > 0 && (
        <div className="overflow-x-auto bg-white rounded-lg border border-gray-200">
          <table className="w-full border-collapse text-xs">
            <thead className="bg-gray-50">
              <tr>
                <th className="border-b border-gray-300 px-1 py-1 text-left font-semibold text-gray-700 text-xs">
                  CONDOMÍNIO
                </th>
                <th className="border-b border-gray-300 px-1 py-1 text-left font-semibold text-gray-700 text-xs">
                  SÍNDICO
                </th>
                <th className="border-b border-gray-300 px-1 py-1 text-left font-semibold text-gray-700 text-xs">
                  INÍCIO
                </th>
                <th className="border-b border-gray-300 px-1 py-1 text-left font-semibold text-gray-700 text-xs">
                  FIM
                </th>
                <th className="border-b border-gray-300 px-1 py-1 text-left font-semibold text-gray-700 text-xs">
                  PREVISÃO
                </th>
                <th className="border-b border-gray-300 px-1 py-1 text-left font-semibold text-gray-700 text-xs">
                  REALIZADA
                </th>
                <th className="border-b border-gray-300 px-1 py-1 text-center font-semibold text-gray-700 text-xs w-12">
                  AÇÕES
                </th>
              </tr>
            </thead>
            <tbody>
              {dadosComAssembleias.map((item) => {
                const previsaoAssembleia = calcularPrevisaoAssembleia(item.dataSaida)
                const assembleia = item.assembleia
                const estaEditando = editandoId === assembleia.id
                
                return (
                  <tr key={item.id} className={getRowStyle(item)}>
                    <td className="px-1 py-0.5 text-xs text-gray-900 leading-tight">
                      {item.condominio}
                    </td>
                    <td className="px-1 py-0.5 text-xs text-gray-900 leading-tight">
                      {item.nomeResponsavel}
                    </td>
                    <td className="px-1 py-0.5 text-xs text-gray-900 leading-tight">
                      {item.dataEntrada || '-'}
                    </td>
                    <td className="px-1 py-0.5 text-xs text-gray-900 leading-tight">
                      {item.dataSaida || '-'}
                    </td>
                    <td className="px-1 py-0.5 text-xs text-gray-900 leading-tight">
                      {previsaoAssembleia}
                    </td>
                    <td className="px-1 py-0.5 text-xs text-gray-900 leading-tight">
                      {estaEditando ? (
                        <input
                          type="text"
                          value={dataRealizadaEditando}
                          onChange={(e) => setDataRealizadaEditando(e.target.value)}
                          placeholder="dd/mm/yyyy"
                          className="w-20 px-1 py-0.5 border border-gray-300 rounded text-xs"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              salvarEdicao(assembleia.id)
                            } else if (e.key === 'Escape') {
                              cancelarEdicao()
                            }
                          }}
                          autoFocus
                        />
                      ) : (
                        <span className={assembleia.realizada ? 'text-green-700 font-medium' : 'text-gray-400'}>
                          {assembleia.realizada || '-'}
                        </span>
                      )}
                    </td>
                    <td className="px-1 py-0.5 text-center">
                      {estaEditando ? (
                        <div className="flex items-center justify-center gap-0.5">
                          <button
                            onClick={() => salvarEdicao(assembleia.id)}
                            className="p-0.5 text-green-600 hover:bg-green-50 rounded"
                            title="Salvar"
                          >
                            <Check size={12} />
                          </button>
                          <button
                            onClick={cancelarEdicao}
                            className="p-0.5 text-red-600 hover:bg-red-50 rounded"
                            title="Cancelar"
                          >
                            <X size={12} />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => iniciarEdicao(assembleia.id, assembleia.realizada)}
                          className="p-0.5 text-blue-600 hover:bg-blue-50 rounded"
                          title="Editar data realizada"
                        >
                          <Edit2 size={12} />
                        </button>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        )}
        
        {/* Rodapé com Paginação - Estilo da imagem */}
        <div className="mt-4 flex items-center justify-between">
          <div className="text-sm text-gray-600">
            Mostrando {dadosComAssembleias.length} resultado(s)
          </div>
          <div className="flex gap-2">
            <button
              disabled
              className="px-3 py-1.5 text-sm border border-gray-300 rounded text-gray-400 cursor-not-allowed"
            >
              ← Anterior
            </button>
            <button
              disabled={dadosComAssembleias.length === 0}
              className="px-3 py-1.5 text-sm border border-gray-300 rounded text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Próximo →
            </button>
          </div>
        </div>
    </div>
  )
}

